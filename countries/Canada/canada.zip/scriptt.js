function toggleDetails(elementId) {
    const info = document.getElementById(elementId);
    info.classList.toggle('hidden');
  }